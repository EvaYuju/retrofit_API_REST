package com.developez.retrofit_apirest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetrofitApirestApplication {

	public static void main(String[] args) {
		SpringApplication.run(RetrofitApirestApplication.class, args);
	}

}
